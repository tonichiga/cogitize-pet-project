import Card from "../../components/card/Card";

const films = [
  {
    id: 1,
    img: "/shan-chi.jpeg",
    title: "Black Widow",
    rate: 6.8,
  },
  {
    id: 2,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Sokol",
    rate: 8.5,
  },
  {
    id: 3,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Rak",
    rate: 8.5,
  },
  {
    id: 4,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Fish",
    rate: 8.5,
  },
  {
    id: 15,
    img: "/shan-chi.jpeg",
    title: "Black Widow",
    rate: 6.8,
  },
  {
    id: 6,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Sokol",
    rate: 8.5,
  },
  {
    id: 7,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Rak",
    rate: 8.5,
  },
  {
    id: 8,
    img: "https://cdn.pixabay.com/photo/2023/09/17/16/02/crab-8258856_1280.jpg",
    title: "Fish",
    rate: 8.5,
  },
];

const Home = ({ onSwitchPage }) => {
  return (
    <div>
      <ul className="list">
        {films.map((film) => {
          return (
            <li key={film.id} onClick={onSwitchPage}>
              <Card />
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default Home;
