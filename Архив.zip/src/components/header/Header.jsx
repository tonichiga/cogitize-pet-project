import "./header.css";

const Header = ({ onSwitchPage }) => {
  return (
    <header className="header">
      <div className="header_container">
        <button onClick={onSwitchPage}> Click to switch</button>
      </div>
    </header>
  );
};

export default Header;
