import "./primary.css";

const Primary = () => {
  return <button className="button_primary">Click me</button>;
};

export default Primary;
