import Primary from "../buttons/primary/Primary";
import "./card.css";

const Card = () => {
  return (
    <div className="card">
      <Primary />
    </div>
  );
};

export default Card;
