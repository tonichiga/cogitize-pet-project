const Library = () => {
  return (
    <div>
      <ul className="list">
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
        <li className="card"></li>
      </ul>
    </div>
  );
};

export default Library;
